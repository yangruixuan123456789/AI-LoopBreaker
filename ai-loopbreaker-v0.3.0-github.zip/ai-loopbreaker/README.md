# LoopBreaker

**中文** | [English](README.en.md)

**让 AI 看见自己正在反复绕过的问题。**

AI 会回答，不等于它在推进。

程序员与 AI 协作时，最常见的问题往往不是“答案不够长”，而是对话一直在换措辞，却没有换证据、换决策或改变可验证的工件。LoopBreaker 是一组可直接注入 AI 编程工具的系统提示词，用来识别这些循环，并迫使 AI 在继续输出前先定位真正卡住的位置。

> 一句话判断是否在循环：**最近两轮是否重复了同一个问题、同一个动作或同一个结论，却没有产生新证据？**

## 它解决的不是“AI 不够努力”

真正的循环通常发生在以下四层：

| 层级 | 表面现象 | 背后没有定位的问题 |
| --- | --- | --- |
| 意图 | AI 很积极地做事，但做的不是用户要的 | 目标、验收标准和非目标没有锁定 |
| 信息 | AI 反复提问，或直接用熟悉假设填空 | 未知信息没有区分“可检查、可推断、必须确认” |
| 行动 | 反复改代码、重试工具、重写计划 | 缺少可证伪假设，动作没有信息增量 |
| 验证 | AI 说“已完成”“应该可以” | 完成标准没有被外部证据验证 |

所以，LoopBreaker 不要求 AI“更仔细一点”。它要求 AI 在每轮工作中维护一个内部状态：

- 目标是什么；
- 什么才算完成；
- 最新一条可信证据是什么；
- 当前最可能错在哪里；
- 下一步动作能排除哪一个不确定性；
- 如果这个动作失败，接下来换什么。

## 13 个常见的 AI 对话循环

| ID | 循环 | 典型表现 | 真正没被处理的问题 |
| --- | --- | --- | --- |
| LB-01 | 目标漂移 | 修了一个相邻问题、做了很多额外功能 | 没有持续对照原始目标 |
| LB-02 | 追问乒乓 | 已经问过的事实再次询问；用户说“不知道”后继续追问 | 没有区分可调查信息与必须由用户决定的信息 |
| LB-03 | 假设隧道 | “通常项目会用 X”，然后围绕 X 设计整套方案 | 把推测当成事实，没有先验证关键假设 |
| LB-04 | 修复打转 | 同一个报错，连续换几种局部补丁 | 没有建立因果模型和最小复现 |
| LB-05 | 假设锁定 | 只寻找支持第一判断的证据 | 没有预先定义什么证据会推翻自己 |
| LB-06 | 上下文失忆 | 忘掉约束、推翻已定决策、重复已完成工作 | 长对话中没有维护可恢复的状态锚点 |
| LB-07 | 工具空转 | 反复搜索、重试、读取，却没有得出结论或执行动作 | 工具调用没有绑定需要回答的问题 |
| LB-08 | 认同循环 | 不断道歉、复述用户观点、表示“你说得对” | 认同没有转化为修正后的决策或工件 |
| LB-09 | 假完成 | “已经修好”“理论上没问题”，但没有运行验证 | 完成被当成语言状态，而不是证据状态 |
| LB-10 | 范围螺旋 | 修一个 bug 时顺手重构整个模块 | 没有区分目标问题、必要依赖和范围外问题 |
| LB-11 | 计划跑步机 | 反复完善方案，迟迟不做最小验证 | 用规划活动替代高信息量的行动 |
| LB-12 | 依赖转移 | 让用户去查 AI 自己可以读取的文件或运行命令 | 没有先穷尽当前权限内的取证手段 |
| LB-13 | 修复覆盖不全 | 用户报告的那一处修好了，相邻入口、状态或调用方仍然出错 | 只关闭了症状，没有关闭同一业务不变量 |

完整的提示词位于 [`prompts/patterns/`](prompts/patterns/)。每个文件都可以单独使用。

## 快速开始

所有可注入的提示词都提供中英文两个独立版本。中文版以 `.zh.md` 结尾，英文版使用基础文件名；完整对应关系记录在 [`prompts/manifest.json`](prompts/manifest.json)。

### 1. 常驻核心提示词

把 [`prompts/core/loopbreaker.zh.md`](prompts/core/loopbreaker.zh.md) 放入中文对话的系统提示词、项目规则或 AI 编程助手的全局指令中。英文工具可选择 [`prompts/core/loopbreaker.md`](prompts/core/loopbreaker.md)。

它会让 AI：

- 每轮比较最近两到三轮是否出现重复；
- 一旦检测到循环，先停止扩写，说明重复动作、最新证据和根因未知项；
- 每轮只推进一个能增加信息或改变状态的步骤；
- 把“完成”绑定到验收标准和验证结果；
- 在追问用户前，先检查信息是否可从上下文、文件或工具中得到。

### 2. 任务开始时加载启动词

把 [`prompts/adapters/kickoff.zh.md`](prompts/adapters/kickoff.zh.md) 附在中文任务开头；英文任务使用 [`prompts/adapters/kickoff.md`](prompts/adapters/kickoff.md)。启动词会为当前会话建立目标、约束、验收和状态锚点。

### 3. 按症状加载专项提示词

例如：

- 同一个 bug 修了两轮仍然失败：加载 `LB-04`；
- 修好一处后，其他入口或状态仍然漏修：加载 `LB-13`；
- AI 反复问同一个问题：加载 `LB-02`；
- 对话越来越长，AI 开始忘记约束：加载 `LB-06`；
- AI 一直给方案但不执行：加载 `LB-11`；
- AI 说完成但没有测试：加载 `LB-09`。

## 不同工具接入

- **Codex / 其他支持 `AGENTS.md` 的工具**：使用 [`prompts/adapters/AGENTS.md`](prompts/adapters/AGENTS.md)。
- **Claude Code**：使用 [`prompts/adapters/CLAUDE.md`](prompts/adapters/CLAUDE.md)。
- **Cursor**：使用 [`prompts/adapters/cursor.mdc`](prompts/adapters/cursor.mdc)。
- **中文项目指令**：使用 [`AGENTS.zh.md`](prompts/adapters/AGENTS.zh.md)、[`CLAUDE.zh.md`](prompts/adapters/CLAUDE.zh.md) 或 [`cursor.zh.mdc`](prompts/adapters/cursor.zh.mdc)。
- **只支持一个系统提示词的工具**：直接复制核心提示词和启动词。

如果你只是想先试一下，可以直接对 AI 说：

```text
在接下来的工作中，请使用 LoopBreaker 协议。

如果连续两轮出现同一种问题、同一个无效动作或同一个没有新证据的结论，立即停止扩写。
先说明：
1. 正在重复什么；
2. 最近一轮产生了什么新证据；
3. 真正阻塞的未知项是什么；
4. 下一项最小、可逆、能增加信息的动作；
5. 什么条件才算完成。

没有新证据时，不要用更长的解释冒充进展。
```

## AI 检测到循环时的输出格式

默认只在发现循环或用户要求审计时展示，避免每轮都产生模板噪声：

```text
LOOP: LB-04 Fix Loop
REPEAT: 连续两次尝试通过修改 mock 让测试通过，但报错位置没有变化。
NEW EVIDENCE: 仅确认 mock 不是首个失败点；尚无调用栈。
ROOT UNKNOWN: 真实执行路径在哪里偏离预期。
NEXT ACTION: 运行最小失败用例并保留完整调用栈，再判断根因。
DONE WHEN: 最小用例通过，且原有相关测试不回归。
DECISION NEEDED: 无。
```

## 设计原则

1. **进展必须有载体**：新证据、新工件、明确决策或已验证状态，至少出现一个。
2. **先证伪，再辩护**：AI 必须说明什么观察会让当前判断失效。
3. **一次只消除一个关键未知**：避免同时改多个变量，导致结果无法解释。
4. **能取证就不转问用户**：只有不可访问的外部状态、高影响偏好或不可逆决策才需要用户确认。
5. **“完成”必须挣得**：没有验收证据，只能报告为“已实现，未验证”。
6. **不把领域提示词当人格设定**：LoopBreaker 约束的是工作状态、证据和决策，不是让 AI 扮演某个角色。

## 仓库结构

```text
.
├── prompts/
│   ├── core/loopbreaker[.zh].md     # 常驻核心协议，中英文独立版本
│   ├── patterns/                    # 13 个专项循环提示词 × 中英文
│   ├── adapters/                    # 常见工具接入片段 × 中英文
│   └── manifest.json                # 语言、文件和适用条件索引
├── docs/
│   ├── why-ai-loops[.en].md         # 循环形成的机制
│   └── prompt-design[.en].md        # 提示词设计原则
├── examples/                        # 循环识别前后对照 × 中英文
├── evals/cases.json                 # 最小评测用例
├── scripts/validate_prompts.py      # 仓库一致性检查
└── scripts/package_release.py       # GitHub 导入包与校验值
```

## 适用边界

LoopBreaker 不会让错误假设自动变成正确事实，也不能替代测试、监控、代码审查或安全边界。它做的是降低一种非常昂贵的失败：**AI 一直显得在协作，但对话已经从解决问题漂移成对问题的高质量描述。**

如果它让 AI 少说一段漂亮话，多做一个能推翻判断的小实验，这个仓库就已经达到目的。

## 双语文档

- 中文说明：[README.md](README.md)
- English overview: [README.en.md](README.en.md)
- 中文循环机制：[why-ai-loops.md](docs/why-ai-loops.md)
- English analysis: [why-ai-loops.en.md](docs/why-ai-loops.en.md)
- 中文贡献指南：[CONTRIBUTING.md](CONTRIBUTING.md)
- English contribution guide: [CONTRIBUTING.en.md](CONTRIBUTING.en.md)
- GitHub 导入说明：[GITHUB_IMPORT.zh.md](GITHUB_IMPORT.zh.md)
- GitHub import guide: [GITHUB_IMPORT.en.md](GITHUB_IMPORT.en.md)

## License

[MIT](LICENSE)
